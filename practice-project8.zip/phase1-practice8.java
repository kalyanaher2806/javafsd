import java.util.*;
public class StringsEx {
	public static void main (String args[])
	{
		String s1="hello";
System.out.println(s1);
String s2 = new String("sky");

System.out.println(s2);
System.out.println(s2.concat("krish"));
System.out.println(s1.equals(s2));
System.out.println(s1.toUpperCase());
System.out.println(s2.toLowerCase());
StringBuffer sb=new StringBuffer("Hello ");  
sb.append("sky"); 
System.out.println(sb);
System.out.println(sb.insert(2,"hi"));
System.out.println(sb.reverse());
String str = "welcome to coversion";
                                       
StringBuffer s3 = new StringBuffer(str);

System.out.println("Converted String to StringBuffer: " + s3);
StringBuffer s4 = new StringBuffer();
System.out.println(s4.append(str));

String strs[] = {"akshy", "jay", "suzii", "vishal"};
System.out.println();
StringBuilder sa = new StringBuilder();//converting to StringBuffer
sa.append(strs[0]);
sa.append(" "+strs[1]);
sa.append(" "+strs[2]);
sa.append(" "+strs[3]);
System.out.println(sa);
//System.out.println(sa.append(strs));
}


}