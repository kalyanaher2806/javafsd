public class AccessModifiers {
    int a=11, b=12;
   public void publicMethod() {
        System.out.println("This is a public method.");
    }

    void defaultMethod() {
        System.out.println("This is a default method");
    }
   

    public static void main(String[] args) {
        AccessModifiers ex = new AccessModifiers();
        System.out.println("number is : " +ex.a);
        ex.publicMethod(); 
        System.out.println("number is : " +ex.b);
        ex.defaultMethod(); 
    }
}