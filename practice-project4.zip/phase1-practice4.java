public class ConstructorsEx {
ConstructorsEx() //default constructor
{
 System.out.println("this is default constructor");
}
ConstructorsEx(int a,int b) // parameterized constructor
{ 
	int c=a+b;
 System.out.println(c);
	}
public static void main (String args[]) {
ConstructorsEx ae=new ConstructorsEx();
ConstructorsEx ce=new ConstructorsEx(5,7);
}
} 