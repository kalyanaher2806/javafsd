import java.util.regex.*;  
class RegexExp{  
public static void main(String args[]){  
 
Pattern p = Pattern.compile(".i");// represents single character  
Matcher m = p.matcher("hi");  
boolean b = m.matches();  
boolean a = Pattern.matches(".i", "hi");  
  
System.out.println(b+" "+a);
System.out.println(Pattern.matches("m.", "mk")); 
System.out.println(Pattern.matches(".s", "mst"));
System.out.println(Pattern.matches(".s", "ms"));
System.out.println(Pattern.matches("..s", "mis"));
System.out.println(Pattern.matches("[hew]?", "h"));//?quantifier
System.out.println(Pattern.matches("[hwwe]?", "hwe"));  
System.out.println(Pattern.matches("[hwwe]+", "hwe"));  // +quantifier
System.out.println(Pattern.matches("[hello]*", "hellooooh")); 
System.out.println("metacharacters");
System.out.println(Pattern.matches("\\d", "abc")); 
System.out.println(Pattern.matches("\\d", "1"));
System.out.println(Pattern.matches("\\D", "a")); 
System.out.println(Pattern.matches("\\D", "1"));
System.out.println(Pattern.matches("[a-zA-Z0-9]{9}", "aahz33456"));


}}  
