import java.util.*;
public class MapsDemo {
	 public static void main(String args[]){  
	  Map<Integer,String> map=new HashMap<Integer,String>();  
	  map.put(1,"jiya");  
	  map.put(2,"harshu");  
	  map.put(3,"priya");  
	for(Map.Entry m:map.entrySet()){  
	   System.out.println(m.getKey()+" "+m.getValue());  
	  } 
	  System.out.println(map);
	  map.put(new Integer(1), "jiya"); //inserting elements
      map.put(new Integer(2), "harshu"); 
      System.out.println(" Map= " + map); 
      map.remove(new Integer(1)); 
      System.out.println(map);
 } 
	 }