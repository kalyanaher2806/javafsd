public class Innerclass {
	String a="hi";
	public void dis() {
		System.out.println(a);
		System.out.println("outerclass");
	}


static class Inner{
	String b="hi";
	public void show() {
		System.out.println(b);
		System.out.println("innerclass");
	}
	}
}

class OuterInner{
	public static void main(String args[]) {
		Innerclass i = new Innerclass();
		i.dis();
		//Innerclass.Inner o = i.new Inner();
		//o.show();
		Innerclass.Inner o = new Innerclass.Inner();
		o.show();
		
	}
	
	
}