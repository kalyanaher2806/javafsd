package practice5;

public class InsertionSort {  
	public static void insertionSort(int num[], int size) {
		for(int i=1;i<size;i++) {
			int key = num[i];
			int j=i-1;
			while(j>=0 && key < num[j]) {
				num[j+1]=num[j];
				j--;
			}
			num[j+1]=key;
		}
	}

    public static void main(String a[]){    
        int[] arr1 = {4,7,2,3,6,8};    
        System.out.println("Before sorting");    
        for(int i:arr1){    
            System.out.print(i+" ");    
        }    
        System.out.println();    
            
        insertionSort(arr1,arr1.length);    
           
        System.out.println("After sorting");    
        for(int i:arr1){    
            System.out.print(i+" ");    
        }    
    }    
}
