package project2;


public class MyRunableThread {
 
    public static int myCount = 0;
    public MyRunableThread()
    {
         
    }
    public void run() {
        while(MyRunableThread.myCount <= 10)
        {
            try{
                System.out.println("Expl Thread: "+(++MyRunableThread.myCount));
                Thread.sleep(100);
            } catch (InterruptedException iex) {
                System.out.println("Exception in thread: "+iex.getMessage());
            }
        }
    } 
    public static void main(String args[])
    {
        System.out.println("Starting Main Thread...");
        MyRunableThread mrt = new MyRunableThread();
        
        while(MyRunableThread.myCount <= 10){
            try{
                System.out.println("Main Thread: "+(++MyRunableThread.myCount));
                Thread.sleep(100);
            } catch (InterruptedException iex){
                System.out.println("Exception in main thread: "+iex.getMessage());
            }
        }
        System.out.println("End of Main Thread...");
    }
}
