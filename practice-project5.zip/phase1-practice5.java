import java.util.* ;
class CollectionDemo {

	public static void main(String[] args) {
	
List<String> list= new ArrayList<String>();
Vector<Integer> v= new Vector<Integer>();
list.add("harshada");
list.add("developer");
v.addElement(1);
v.addElement(2);
System.out.println(list);
System.out.println(v);
Stack<String> stack = new Stack<String>();  
stack.push("1");  
stack.push("5");  
stack.push("4");  
stack.pop();  
Iterator<String> itr=stack.iterator();  
while(itr.hasNext()){  
System.out.println(itr.next());  
}
	}
}

